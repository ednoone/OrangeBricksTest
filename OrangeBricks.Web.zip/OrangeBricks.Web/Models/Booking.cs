using System;
using System.ComponentModel.DataAnnotations;

namespace OrangeBricks.Web.Models
{
    public class Booking
    {
        [Key]
        public int Id { get; set; }

        public string BookDay { get; set; }

        public string BookTime { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }
    }
}
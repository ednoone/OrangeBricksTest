﻿namespace OrangeBricks.Web.Models
{
    public enum OfferStatus
    {
        Pending,
        Accepted,
        Rejected
    }
}
namespace OrangeBricks.Web.Controllers.Property.ViewModels
{
    public class BookViewingViewModel
    {
        public string PropertyType { get; set; }
        public string StreetName { get; set; }
        public string BookDay { get; set; }
        public string BookTime { get; set; }
        public int PropertyId { get; set; }
    }
}
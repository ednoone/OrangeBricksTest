using System;
using System.Collections.Generic;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Property.Commands
{
    public class BookViewingCommandHandler
    {
        private readonly IOrangeBricksContext _context;

        public BookViewingCommandHandler(IOrangeBricksContext context)
        {
            _context = context;
        }

        public void Handle(BookViewingCommand command)
        {
            var property = _context.Properties.Find(command.PropertyId);

            var booking = new Booking
            {
                BookDay = command.BookDay,
                BookTime = command.BookTime,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            if (property.Bookings == null)
            {
                property.Bookings = new List<Booking>();
            }

            property.Bookings.Add(booking);
            
            _context.SaveChanges();
        }
    }
}
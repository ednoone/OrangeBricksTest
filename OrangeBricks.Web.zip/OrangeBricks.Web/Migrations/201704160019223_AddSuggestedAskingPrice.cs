namespace OrangeBricks.Web.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddSuggestedAskingPrice : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Properties", "SuggestedAskingPrice", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Properties", "SuggestedAskingPrice");
        }
    }
}
